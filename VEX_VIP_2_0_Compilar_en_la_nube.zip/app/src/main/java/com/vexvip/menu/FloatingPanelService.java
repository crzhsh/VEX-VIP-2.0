package com.vexvip.menu;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class FloatingPanelService extends Service {
    WindowManager wm; View panel; boolean expanded=true;
    int red=0xffff3030;
    public IBinder onBind(Intent i){return null;}
    GradientDrawable shape(int color) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(22);
        d.setStroke(2,red); return d;
    }
    public void onCreate() {
        super.onCreate();
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.setPadding(14,10,14,12);
        box.setBackground(shape(0xee101010));
        TextView head=new TextView(this); head.setText("VEX VIP  •  TOCA PARA OCULTAR"); head.setTextColor(-1);
        head.setTextSize(12); head.setPadding(5,5,5,10); box.addView(head);
        head.setOnClickListener(v->{expanded=!expanded; for(int n=1;n<box.getChildCount();n++)box.getChildAt(n).setVisibility(expanded?View.VISIBLE:View.GONE);});
        String[] names={"General","Punto rojo","Mira 2X","Mira 4X"};
        int[] vals={95,90,85,80};
        for(int j=0;j<names.length;j++){
            TextView tv=new TextView(this); tv.setText(names[j]+" • "+vals[j]); tv.setTextColor(-1); tv.setTextSize(12); box.addView(tv);
            SeekBar sb=new SeekBar(this); sb.setMax(200); sb.setProgress(vals[j]);
            sb.setProgressTintList(android.content.res.ColorStateList.valueOf(red));
            sb.setThumbTintList(android.content.res.ColorStateList.valueOf(red));
            final TextView target=tv; final String nm=names[j];
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                public void onProgressChanged(SeekBar b,int p,boolean u){target.setText(nm+" • "+p);}
                public void onStartTrackingTouch(SeekBar b){}
                public void onStopTrackingTouch(SeekBar b){}
            }); box.addView(sb);
        }
        TextView close=new TextView(this); close.setText("CERRAR PANEL"); close.setTextColor(red); close.setPadding(5,10,5,5); box.addView(close);
        close.setOnClickListener(v->stopSelf());
        panel=box;
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END; p.x=18; p.y=140;
        wm.addView(panel,p);
    }
    public void onDestroy(){if(wm!=null&&panel!=null)wm.removeView(panel);super.onDestroy();}
}
