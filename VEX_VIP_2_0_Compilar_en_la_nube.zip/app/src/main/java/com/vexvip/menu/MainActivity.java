package com.vexvip.menu;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;

public class MainActivity extends Activity {
    int red = Color.rgb(255,48,48);
    LinearLayout root;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(9,9,9));
        getWindow().setNavigationBarColor(Color.rgb(9,9,9));
        showMain();
    }
    GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if(stroke>0) d.setStroke(2, red);
        return d;
    }
    TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); return t;
    }
    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(red));
        return b;
    }
    void gap(int h) { View v=new View(this); root.addView(v,new LinearLayout.LayoutParams(1,h)); }
    void heading(String s) {
        gap(15); TextView t=label(s,15,red); t.setTypeface(null,Typeface.BOLD);
        root.addView(t);
        View line=new View(this); line.setBackgroundColor(0xff552222);
        root.addView(line,new LinearLayout.LayoutParams(-1,1));
    }
    void showMain() {
        ScrollView sc=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(22,24,22,24);
        root.setBackgroundColor(0xff090909); sc.addView(root);
        TextView title=label("VEX VIP",30,Color.WHITE); title.setGravity(17); title.setTypeface(null,1); root.addView(title);
        TextView sub=label("VERSION 2.0  •  ANDROID TOOLKIT",11,red); sub.setGravity(17); root.addView(sub);
        heading("SENSIBILIDAD (REFERENCIA)");
        addSeek("General",95); addSeek("Punto rojo",90); addSeek("Mira 2X",85);
        addSeek("Mira 4X",80); addSeek("Francotirador",50); addSeek("Cámara",90);
        heading("PERFILES");
        Button balanced=btn("PERFIL EQUILIBRADO");
        balanced.setOnClickListener(v -> Toast.makeText(this,"Perfil equilibrado seleccionado",0).show()); root.addView(balanced);
        Button custom=btn("PERFIL PERSONALIZADO");
        custom.setOnClickListener(v -> Toast.makeText(this,"Ajusta los controles de sensibilidad arriba",0).show()); root.addView(custom);
        heading("ACCESOS RÁPIDOS");
        Button ff=btn("ABRIR FREE FIRE");
        ff.setOnClickListener(v -> launchGame("com.dts.freefireth","com.dts.freefiremax")); root.addView(ff);
        Button ffm=btn("ABRIR FREE FIRE MAX");
        ffm.setOnClickListener(v -> launchGame("com.dts.freefiremax","com.dts.freefireth")); root.addView(ffm);
        Button overlay=btn("ACTIVAR PANEL FLOTANTE");
        overlay.setOnClickListener(v -> {
            if(!Settings.canDrawOverlays(this)) {
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
            } else { startService(new Intent(this, FloatingPanelService.class)); Toast.makeText(this,"Panel flotante activado",0).show(); }
        });
        root.addView(overlay);
        gap(15);
        TextView foot=label("Los valores son referencias para introducir manualmente en los ajustes del juego. Esta app no altera Free Fire.",11,0xffaaaaaa);
        foot.setGravity(17); root.addView(foot);
        setContentView(sc);
    }
    void addSeek(String name,int initial) {
        TextView t=label(name+"  •  "+initial,14,Color.WHITE); root.addView(t);
        SeekBar s=new SeekBar(this); s.setMax(200); s.setProgress(initial);
        s.setProgressTintList(android.content.res.ColorStateList.valueOf(red));
        s.setThumbTintList(android.content.res.ColorStateList.valueOf(red));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int p,boolean u){t.setText(name+"  •  "+p);}
            public void onStartTrackingTouch(SeekBar b){}
            public void onStopTrackingTouch(SeekBar b){}
        }); root.addView(s);
    }
    void launchGame(String first,String second) {
        Intent i=getPackageManager().getLaunchIntentForPackage(first);
        if(i==null)i=getPackageManager().getLaunchIntentForPackage(second);
        if(i==null) Toast.makeText(this,"No se encontró Free Fire instalado",0).show();
        else startActivity(i);
    }
}
